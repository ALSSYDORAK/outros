package exercicio11_09;

public class ContaCorrente extends contaBancaria {
    private static final double TAXA_SAQUE = 0.05;
    private static final double TAXA_MANUTENCAO = 10.0;

    public ContaCorrente(String titular, double saldo) {
        super(titular, saldo);
    }

    @Override
    public String sacar(double valor) {
        double valorTotal = valor + (valor * TAXA_SAQUE) + TAXA_MANUTENCAO;
        if (valorTotal <= saldo) {
            saldo -= valorTotal;
            return "Saque realizado com sucesso na Conta Corrente de " + titular +
                   ". Valor sacado: " + valor + ", taxa: " + (valor * TAXA_SAQUE) + ", taxa de manutenção: " + TAXA_MANUTENCAO;
        } else {
            return "Saldo insuficiente para realizar o saque na Conta Corrente de " + titular + ".";
        }
    }

    public void exibirSaldo() {
        System.out.println("Saldo da Conta Corrente de " + titular + ": " + saldo);
    }
}
