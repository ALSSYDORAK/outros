package exercicio11_09;

import java.util.ArrayList;
import java.util.List;

public class Banco {
    private List<contaBancaria> contas;
    private static final int MAX_CONTAS = 5;

    public Banco() {
        contas = new ArrayList<>();
    }

    public void adicionarConta(contaBancaria conta) {
        if (contas.size() < MAX_CONTAS) {
            contas.add(conta);
        } else {
            System.out.println("Número máximo de contas alcançado.");
        }
    }

    public void adicionarConta(String tipo, String titular, double saldoInicial) {
        if (contas.size() < MAX_CONTAS) {
            contaBancaria conta;
            switch (tipo.toLowerCase()) {
                case "corrente":
                    conta = new ContaCorrente(titular, saldoInicial);
                    break;
                case "poupanca":
                    conta = new ContaPoupanca(titular, saldoInicial);
                    break;
                default:
                    System.out.println("Tipo de conta inválido. Use 'corrente' ou 'poupanca'.");
                    return;
            }
            contas.add(conta);
        } else {
            System.out.println("Número máximo de contas alcançado.");
        }
    }

    public List<String> realizarSaques(double valor) {
        List<String> detalhesSaques = new ArrayList<>();
        for (contaBancaria conta : contas) {
            detalhesSaques.add(conta.sacar(valor));
        }
        return detalhesSaques;
    }

    public List<String> resumoContas() {
        List<String> resumo = new ArrayList<>();
        for (contaBancaria conta : contas) {
            String tipoConta = conta instanceof ContaCorrente ? "Conta Corrente" : "Conta Poupança";
            resumo.add(String.format("%s: Titular: %s, Saldo: %.2f", tipoConta, conta.getTitular(), conta.consultarSaldo()));
        }
        return resumo;
    }
}
