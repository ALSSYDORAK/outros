package exercicio11_09;

import java.util.List;

public class teste {
    public static void main(String[] args) {
        Banco banco = new Banco();
        
        banco.adicionarConta(new ContaCorrente("João", 1000.0));
        banco.adicionarConta(new ContaPoupanca("Maria", 500.0));
        banco.adicionarConta("corrente", "Ana", 2000.0);
        banco.adicionarConta("poupanca", "Pedro", 1500.0);
        
        
        List<String> resumo = banco.resumoContas();
        for (String info : resumo) {
            System.out.println(info);
        }
    }
}
