package exercicio11_09;

public class ContaPoupanca extends contaBancaria {

    public ContaPoupanca(String titular, double saldo) {
        super(titular, saldo);
    }

    @Override
    public String sacar(double valor) {
        if (valor <= saldo) {
            saldo -= valor;
            return "Saque realizado com sucesso na Conta Poupança de " + titular + ". Valor sacado: " + valor;
        } else {
            return "Saldo insuficiente para realizar o saque na Conta Poupança de " + titular + ".";
        }
    }

    public void exibirSaldo() {
        System.out.println("Saldo da Conta Poupança de " + titular + ": " + saldo);
    }
}
