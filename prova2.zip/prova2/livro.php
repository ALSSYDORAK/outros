<!DOCTYPE html>
<html>
<head>
<title>Cadastro de Produtos</title>
<?php include ('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="livro.php" method="post" name="livro">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro livro</td>
  </tr>
  <tr>
    <td>titulo:</td>
    <td><input type="text" name="titulo" ></td>
  </tr>
  <tr>
    <td>Quantidade em Estoque:</td>
    <td><input type="text" name="quantidade" ></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
  </tr>
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
{
    $titulo = $_POST['titulo'];
    $quantidade = $_POST['quantidade'];

    
    $insere_livro = "INSERT INTO livro (titulo, quantidade) VALUES ('$titulo', '$quantidade')";
    mysqli_query($mysqli, $insere_livro) or die ("Não foi possivel inserir os dados do livro");
}



?>  

<a href="index.html" >Home </a>
</body>
</html>
