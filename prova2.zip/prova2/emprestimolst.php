<!DOCTYPE html>
<html>
<head>
<title>Relatório de Empréstimos</title>
<?php include ('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="emprestimolst.php" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan="5" align="center">Relatório de Empréstimos</td>
  </tr>
  <tr>
    <td width="9%" align="right">Nome do aluno:</td>
    <td width="30%"><input type="text" name="nome" /></td>
    <td width="12%" align="right">Título do livro:</td>
    <td width="26%"><input type="text" name="titulo" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">
    <th width="25%">Nome do aluno</th>
    <th width="20%">Título do livro</th>
    <th width="10%">Data do empréstimo</th>
  </tr>

<?php
  $nome_aluno = $_POST['nome'];
  $titulo_livro = $_POST['titulo'];
  
  $query = "SELECT aluno.nome AS nome_aluno, livro.titulo AS titulo_livro, emprestimo.data AS data_emprestimo
            FROM emprestimo
            INNER JOIN aluno ON emprestimo.fk_aluno_matricula = aluno.matricula
            INNER JOIN livro ON emprestimo.fk_livro_codigo = livro.codigo
            WHERE 1";
  
  if (!empty($nome_aluno)) {
    $query .= " AND aluno.nome LIKE '%$nome_aluno%'";
  }
  if (!empty($titulo_livro)) {
    $query .= " AND livro.titulo LIKE '%$titulo_livro%'";
  }
  
  $query .= " ORDER BY aluno.nome";

  $result = mysqli_query($mysqli, $query);

  while ($row = mysqli_fetch_assoc($result)) {
?>
    <tr>
      <td><?php echo htmlspecialchars($row['nome_aluno']); ?></td>
      <td><?php echo htmlspecialchars($row['titulo_livro']); ?></td>
      <td><?php echo htmlspecialchars($row['data_emprestimo']); ?></td>
    </tr>
<?php
  }
?>
</table>
<?php } ?>
</body>
</html>
