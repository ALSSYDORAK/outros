<!DOCTYPE html>
<html>
<head>
<title>Registro de Empréstimos</title>
<?php include('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<h2>Registro de Empréstimo</h2>
<form action="emprestimo.php" method="post" name="emprestimo">
<table width="200" border="1">
  <tr>
    <td colspan="2">Registrar Empréstimo</td>
  </tr>
  <tr>
    <td>Matrícula do Aluno:</td>
    <td>
      <select name="fk_aluno_matricula">
        <?php
        $query_alunos = "SELECT matricula, nome FROM aluno";
        $result_alunos = mysqli_query($mysqli, $query_alunos);
        while ($row_aluno = mysqli_fetch_assoc($result_alunos)) {
          echo "<option value='{$row_aluno['matricula']}'>{$row_aluno['nome']}</option>";
        }
        ?>
      </select>
    </td>
  </tr>
  <tr>
    <td>Código do Livro:</td>
    <td>
      <select name="fk_livro_codigo">
        <?php
        $query_livros = "SELECT codigo, titulo FROM livro WHERE quantidade > 0";
        $result_livros = mysqli_query($mysqli, $query_livros);
        while ($row_livro = mysqli_fetch_assoc($result_livros)) {
          echo "<option value='{$row_livro['codigo']}'>{$row_livro['titulo']}</option>";
        }
        ?>
      </select>
    </td>
  </tr>
  <tr>
    <td>Data do Empréstimo:</td>
    <td><input type="date" name="data"></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Registrar" name="botao_emprestimo"></td>
  </tr>
</table>
</form>

<?php
if (@$_POST['botao_emprestimo'] == "Registrar") 
{
    $fk_aluno_matricula = $_POST['fk_aluno_matricula'];
    $fk_livro_codigo = $_POST['fk_livro_codigo'];
    $data = $_POST['data'];

    // Verifica se há pelo menos um livro disponível
    $query_estoque = "SELECT quantidade FROM livro WHERE codigo = '$fk_livro_codigo'";
    $result_estoque = mysqli_query($mysqli, $query_estoque);
    $row_estoque = mysqli_fetch_assoc($result_estoque);

    if ($row_estoque['quantidade'] > 0) {
        // Insere o registro de empréstimo
        $insere_emprestimo = "INSERT INTO emprestimo (fk_aluno_matricula, fk_livro_codigo, data) VALUES ('$fk_aluno_matricula', '$fk_livro_codigo', '$data')";
        
        if (mysqli_query($mysqli, $insere_emprestimo)) {
            // Atualiza a quantidade de livros
            $atualiza_livro = "UPDATE livro SET quantidade = quantidade - 1 WHERE codigo = '$fk_livro_codigo'";
            mysqli_query($mysqli, $atualiza_livro) or die ("Erro ao atualizar a quantidade de livros");
            echo "Empréstimo registrado com sucesso!";
        } else {
            echo "Não foi possível registrar o empréstimo: " . mysqli_error($mysqli);
        }
    } else {
        echo "Não há exemplares suficientes do livro para realizar o empréstimo.";
    }
}
?>

<a href="index.html">Home</a>
</body>
</html>
