<html>
<head>
<title>Compra</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="compra.php" method="post" name="compra">
<table width="200" border="1">
  <tr>
    <td colspan="2">Compra do Produto</td>
  </tr>
  <tr>
    <td>Quantidade da Compra:</td>
    <td><input type="text" name="qtdeCompra" ></td>
  </tr>
  <tr>
    <td>Data da Compra:</td>
    <td><input type="date" name="dataCompra" ></td>
  </tr>
  <tr>
    <td>Codigo Cliente:</td>
    <td><input type="int" name="codigoC" ></td>
  </tr>
  <tr>
    <td>Código Produto:</td>
    <td><input type="int" name="codigoP" ></td>
  </tr>
    <tr>
     <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>
<?php
if (@$_POST['botao'] == "Gravar") 
{
    $qtdeCompra = $_POST['qtdeCompra'];
    $dataCompra = $_POST['dataCompra'];
    $codigoC = $_POST['codigoC'];
    $codigoP = $_POST['codigoP'];

    $verificaEstoque = "SELECT QTDE_ESTOQUE FROM PRODUTO WHERE CODIGO = '$codigoP'";
    $resultado = $mysqli->query($verificaEstoque);
    if ($resultado && $resultado->num_rows > 0) 
    {
        $row = $resultado->fetch_assoc();
        $qtde_estoque = $row['QTDE_ESTOQUE'];
        
        if ($qtdeCompra > $qtde_estoque) 
        {
            echo ("Estoque insuficiente");
        } else 
          {
            $insereCompra = "INSERT INTO COMPRA (FK_PRODUTO_CODIGO, FK_CLIENTE_CODIGO, DATA, QTDE_VENDA) 
            VALUES ('$codigoP', '$codigoC', '$dataCompra','$qtdeCompra')";
            $mysqli->query($insereCompra) or die ("Não foi possível inserir os dados");

            $novoEstoque = $qtde_estoque - $qtdeCompra; 
            $atualizaEstoque = "UPDATE PRODUTO SET QTDE_ESTOQUE = '$novoEstoque' WHERE CODIGO = '$codigoP'";
            $mysqli->query($atualizaEstoque) or die ("Não foi possível atualizar o estoque");

            echo ("Compra realizada com sucesso");
         }
    } else {
        echo ("Produto não encontrado");
      }
}
?>
<br><a href="index.html" >Home </a>
</body>
</html>
