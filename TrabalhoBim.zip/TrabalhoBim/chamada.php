<html>
<head>
<title>Relatório de Matrículas</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="chamada.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan=5 align="center">Chamada Alunos</td>
  </tr>
  <tr>
    <td width="9%" align="right">Nome Aluno:</td>
    <td width="30%"><input type="text" name="nome"  /></td>
    <td width="12%" align="right">Turma</td>
    <td width="26%"><input type="text" name="turma" size="3" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">
    <th width="25%">Nome do Aluno</th>
    <th width="10%">Turma</th>
  </tr>

<?php

	$nome = $_POST['nome'];
	$turma = $_POST['turma'];
	
	$query = "SELECT TURMA as turma, aluno.NOME as nomeA
			  FROM aluno 
        inner join cursa on aluno.CODIGO=cursa.ALUNO_CODIGO
        inner join disciplina on disciplina.CODIGO=cursa.DISCIPLINA_CODIGO 
        inner join municipio on municipio.CODIGO = aluno.MUNICIPIO_CODIGO
        inner join uf on uf.CODIGO = municipio.UF_CODIGO
        WHERE aluno.CODIGO > 0 ";
	$query .= ($nome ? " AND ALUNO.NOME LIKE '%$nome%' " : "");
	$query .= ($turma ? " AND turma LIKE '%$turma%' " : "");
    $query .= " ORDER BY turma, nomeA";
	$result = mysqli_query($mysqli, $query);

	while ($coluna=mysqli_fetch_array($result)) 
	{
	  ?>
    <tr>
        <th width="20%"><?php echo $coluna['turma'] ?></th>
        <th width="25%"><?php echo $coluna['nomeA']; ?></th>
    </tr>
    <?php
	
	} // fim while
?>
</table>
<?php	
}
?>
<a href="index.html" >Home </a>

</body>
