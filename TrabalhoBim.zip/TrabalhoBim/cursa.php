<html>
<head>
<title>Matrícula de Alunos</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="cursa.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Matrícula de Alunos</td>
  </tr>
  <tr>
    <td>Turma:</td>
    <td><input type="text" name="turma" ></td>
  </tr>
  <tr>
    <td>Ano:</td>
    <td><input type="numeric" name="ano" ></td>
  </tr>
  <tr>
    <td>Nota 1:</td>
    <td><input type="numeric" name="nota1" ></td>
  </tr>
  <tr>
    <td>Nota 2:</td>
    <td><input type="numeric" name="nota2" ></td>
  </tr>
  <tr>
    <td>Codigo Aluno:</td>
    <td><input type="int" name="matricula" ></td>
  </tr>
  <tr>
    <td>Código Disciplina:</td>
    <td><input type="int" name="codigo" ></td>
  </tr>
  </tr>
    <td>Total Faltas</td>
    <td><input type="int" name="totalFaltas" ></td>
  </tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>
<?php
if (@$_POST['botao'] == "Gravar") 
	{
    $turma = $_POST['turma'];
    $ano = $_POST['ano'];
    $nota1 = $_POST['nota1'];
    $nota2 = $_POST['nota2'];
    $matricula = $_POST['matricula'];
    $codigo = $_POST['codigo'];
    $totalFaltas = $_POST['totalFaltas'];

    // Para verificar se o aluno já cursou a disciplina no mesmo ano
    $consulta_cursou = "SELECT * FROM cursa WHERE ALUNO_CODIGO = '$matricula' AND DISCIPLINA_CODIGO = '$codigo' AND ano = '$ano'";
    $resultado_cursou = mysqli_query($mysqli, $consulta_cursou);
    $ja_cursou = mysqli_num_rows($resultado_cursou);

    // Verificar se o aluno já foi aprovado na disciplina
    $consulta_aprovado = "SELECT * FROM cursa WHERE ALUNO_CODIGO = '$matricula' AND DISCIPLINA_CODIGO = '$codigo' AND ((nota1 + nota2)/2) >= 7";
    $resultado_aprovado = mysqli_query($mysqli, $consulta_aprovado);
    $ja_aprovado = mysqli_num_rows($resultado_aprovado);

    // Verificar se a turma está lotada
    $consulta_turma = "SELECT turma FROM cursa WHERE turma = '$turma'";
    $resultado_turma = mysqli_query($mysqli, $consulta_turma);
    $total_alunos = mysqli_num_rows($resultado_turma);

    if ($ja_cursou > 0) {
      echo "O aluno já cursou essa disciplina neste ano.";
    } elseif ($ja_aprovado > 0) {
      echo "O aluno já foi aprovado nessa disciplina e não pode ser matriculado novamente.";
    } elseif ($total_alunos > 30) {
      echo "Turma lotada";
    }
    else{
    $insere = "INSERT into cursa(TURMA, ANO, NOTA1, NOTA2, ALUNO_CODIGO, DISCIPLINA_CODIGO, FALTAS) 
    VALUES ('$turma', '$ano', '$nota1','$nota2','$matricula', '$codigo', '$totalFaltas')";
    mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
    }
	}
?>
<a href="index.html" >Home </a>
</body>
</html>
