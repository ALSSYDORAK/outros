<html>
<head>
<title>Relatório de Matrículas</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="relatorioMensalidade.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan=5 align="center">Relatório do Aluno</td>
  </tr>
  <tr>
    <td width="9%" align="right">Região:</td>
    <td width="30%"><input type="text" name="regiao"  /></td>
    <td width="12%" align="right">Ano</td>
    <td width="26%"><input type="text" name="ano" size="3" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">
    <th width="25%">Região</th>
    <th width="10%">Ano</th>
    <th width="25%">Disciplina</th>
    <th width="25%">Total Mensalidade</th>
  </tr>

<?php

	$regiao = $_POST['regiao'];
	$ano = $_POST['ano'];
	
	$query = "SELECT REGIAO as regiao, ANO as ano, DISCIPLINA.NOME as disciplina, SUM(MENSALIDADE) as totalMensalidade
			  FROM CURSA 
        inner join aluno on aluno.CODIGO=cursa.ALUNO_CODIGO
        inner join disciplina on disciplina.CODIGO=cursa.DISCIPLINA_CODIGO 
        inner join municipio on municipio.CODIGO = aluno.MUNICIPIO_CODIGO
        inner join uf on uf.CODIGO = municipio.UF_CODIGO
        WHERE CURSA.ANO > 0";
	$query .= ($regiao ? " AND UF.REGIAO LIKE '%$regiao%' " : "");
	$query .= ($ano ? " AND CURSA.ANO LIKE '%$ano%' " : "");
	$query .= " GROUP BY regiao, ano, disciplina";
	$result = mysqli_query($mysqli, $query);

	while ($coluna=mysqli_fetch_array($result)) 
	{
	  ?>
    <tr>
      <th width="25%"><?php echo $coluna['regiao']; ?></th>
      <th width="20%"><?php echo $coluna['ano'] ?></th>
      <th width="20%"><?php echo $coluna['disciplina']; ?></th>
      <th width="20%"><?php echo $coluna['totalMensalidade']; ?></th>
    </tr>
    <?php
	
	} // fim while
?>
</table>
<?php	
}
?>
<a href="index.html" >Home </a>

</body>
