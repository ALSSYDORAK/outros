<html>

<head>
<title>Cadastro de Disciplinas</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="disciplina.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de Disciplinas</td>
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>Ementa:</td> <!-- Conteudos passados nas aulas de uma disciplina-->
    <td><input type="text" name="ementa" ></td>
  </tr>
  <tr>
    <td>Numero de Aulas:</td>
    <td><input type="number" name="nr_aulas" ></td>
  </tr>
  <tr>
    <td>Mensalidade:</td>
    <td><input type="number" name="mensalidade" ></td>
  </tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>
<?php
if (@$_POST['botao'] == "Gravar") 
	{
   
    $nome = $_POST['nome'];
    $ementa = $_POST['ementa'];
    $nr_aulas = $_POST['nr_aulas'];
    $mensalidade = $_POST['mensalidade'];

		$insere = "INSERT into disciplina (NOME, EMENTA, NR_AULAS, MENSALIDADE) VALUES ('$nome', '$ementa', '$nr_aulas', '$mensalidade')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}
?>
<a href="index.html" >Home </a>
</body>
</html>
