<html>
<head>
<title>Relatório do Aluno</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="relatorio.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan=7 align="center">Relatório do Aluno</td>
  </tr>
  <tr>
  <td width="9%" align="right">Codigo Aluno</td>
    <td width="20%"><input type="text" name="codigoAlu"  /></td>
    <td width="9%" align="right">Nome</td>
    <td width="30%"><input type="text" name="nomeAlu"  /></td>
    <td width="9%" align="right">Data de nascimento</td>
    <td width="30%"><input type="text" name="dataNcto"  /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">    
    <th width="10%">Codigo do Aluno</th>
    <th width="25%">Nome do Aluno</th>
    <th width="20%">Nome do Municipio</th>
    <th width="10%">Nome da UF</th>
  </tr>

<?php

    $codigoAlu = $_POST['codigoAlu'];
	$nomeAlu = $_POST['nomeAlu'];
    $dataNcto = $_POST['dataNcto'];
	
	$query = "SELECT CODIGOALU, NOMEALU 
			  FROM aluno     
			  WHERE aluno.CODIGOALU > 0 ";
    $query .= ($nomeAlu ? " AND NOMEALU LIKE '%$nomeAlu%' " : "");
    $query .= ($dataNcto ? " AND DATA_NCTO LIKE '%$dataNcto%' " : "");
    $query .= ($codigoAlu ? " AND CODIGOALU LIKE '%$codigoAlu%' " : "");
	$query .= " ORDER by aluno.CODIGOALU";
	$result = mysqli_query($mysqli, $query);

	while ($coluna=mysqli_fetch_array($result)) 
	{
		
	?>
    <tr>
      <th width="10%"><?php echo $coluna['CODIGOALU']; ?></th>
      <th width="25%"><?php echo $coluna['NOMEALU']; ?></th>
      <th width="20%"><?php echo 'Curitiba'; ?></th>
      <th width="10%"><?php echo 'PR'; ?></th>
  	</tr>
    <?php
	
	}
?>
</table>
<?php	
}
?>
<a href="index.html" >Home </a>

</body>