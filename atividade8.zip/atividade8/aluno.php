<html>

<head>
<title>Cadastro de Aluno</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="aluno.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de Aluno</td>
  </tr>
  <tr>
    <td width="53">Cod. Aluno</td>
    <td width="131">&nbsp;
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nomeAlu" ></td>
  </tr>
  <tr>
    <td>Data de nascimento</td>
    <td><input type="date" name="dataNcto"></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
	{
		$nomeAlu = $_POST['nomeAlu'];
		$dataNcto = $_POST['dataNcto'];
		
		$insere = "INSERT into aluno (NOMEALU, DATA_NCTO) VALUES ('$nomeAlu', '$dataNcto')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}

?>  

<a href="index.html" >Home </a>
</body>
</html>