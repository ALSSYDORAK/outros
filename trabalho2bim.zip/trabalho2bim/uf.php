<html>

<head>
<title>Cadastro de UF</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="uf.php" method="post" name="nome">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de UF</td>
  </tr>
  <tr>
    <td width="53">Cod.</td>
    <td width="131">&nbsp;
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>Região</td>
    <td><input type="text" name="regiao" ></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
	{
		
    $nome = $_POST['nome'];
    $regiao = $_POST['regiao'];

		$insere = "INSERT into uf (nome, regiao) VALUES ('$nome', '$regiao')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}

?>  

<a href="index.html" >Home </a>
</body>
</html>