<html>

<head>
<title>Cadastro de municipio</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="municipio.php" method="post" name="nome">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro municipio</td>
  </tr>
  <tr>
    <td width="53">Cod.</td>
    <td width="131">&nbsp;
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>População</td>
    <td><input type="int" name="populacao" ></td>
  </tr>
  <tr>
    <td>UF</td>
    <td><input type="int" name="fk_uf_codigo" ></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
	{
		
    $nome = $_POST['nome'];
    $populacao = $_POST['populacao'];
    $uf = $_POST['fk_uf_codigo'];
    
		$insere = "INSERT into municipio (nome, populacao, fk_uf_codigo) VALUES ('$nome', '$populacao', '$fk_uf_codigo')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}

?>  

<a href="index.html" >Home </a>
</body>
</html>