<html>
<head>
<title>Matrícula de Alunos</title>
<?php include ('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<form action="cursa.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Lançamento de dados</td>
  </tr>
  <tr>
    <td>ano</td>
    <td><input type="int" name="ano"></td>
  </tr>
  <tr>
    <td>Matrícula Aluno:</td>
    <td><input type="number" name="fk_aluno_codigo"></td>
  </tr>
  <tr>
    <td>Turma do aluno:</td>
    <td><input type="text" name="turma"></td>
  </tr>
  <tr>
    <td>código da disciplina:</td>
    <td><input type="number" name="fk_disciplina_codigo"></td>
  </tr>
  <tr>
    <td>Nota 1:</td>
    <td><input type="number" name="nota1"></td>
  </tr>
  <tr>
    <td>Nota 2:</td>
    <td><input type="number" name="nota2"></td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
  </tr>
</table>
</form>
<?php
if (@$_POST['botao'] == "Gravar") {
    $ano = $_POST['ano'];
    $matricula = $_POST['fk_aluno_codigo'];
    $turma = $_POST['turma'];
    $cod_disciplina = $_POST['fk_disciplina_codigo'];
    $nota1 = $_POST['nota1'];
    $nota2 = $_POST['nota2'];

    $consulta_cursou = "SELECT * FROM cursa WHERE fk_aluno_codigo = '$matricula' AND fk_disciplina_codigo = '$cod_disciplina' AND ano = '$ano'";
    $resultado_cursou = mysqli_query($mysqli, $consulta_cursou);
    $ja_cursou = mysqli_num_rows($resultado_cursou);

    $consulta_aprovado = "SELECT * FROM cursa WHERE fk_aluno_codigo = '$matricula' AND fk_disciplina_codigo = '$cod_disciplina' AND ((nota1 + nota2)/2) >= 70";
    $resultado_aprovado = mysqli_query($mysqli, $consulta_aprovado);
    $ja_aprovado = mysqli_num_rows($resultado_aprovado);

    $consulta_turma = "SELECT turma FROM cursa WHERE turma = '$turma'";
    $resultado_turma = mysqli_query($mysqli, $consulta_turma);
    $total_alunos = mysqli_num_rows($resultado_turma);

    if ($ja_cursou > 0) {
        echo "O aluno já cursou essa disciplina no mesmo ano.";
    } elseif ($ja_aprovado > 0) {
        echo "O aluno já foi aprovado nessa disciplina e não pode ser matriculado novamente.";
    } elseif ($total_alunos > 30) {
        echo "Turma lotada";
    } else {
        $insere = "INSERT INTO cursa (ano, fk_aluno_codigo, turma, fk_disciplina_codigo, nota1, nota2) 
                   VALUES ('$ano', '$matricula', '$turma', '$cod_disciplina', '$nota1', '$nota2')";
        mysqli_query($mysqli, $insere) or die("Não foi possível inserir os dados");
    }
}
?>

<br><a href="index.html">Home</a> 
</body>
</html>
