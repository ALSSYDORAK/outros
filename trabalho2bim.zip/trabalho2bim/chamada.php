<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Lista de Chamada dos Alunos</title>
    <?php include('config.php'); ?>
</head>
<body>
    <form action="chamada.php" method="post" name="form1">
        <table width="95%" border="1" align="center">
            <tr>
                <td colspan="5" align="center">Relatório de Lista de Chamada dos Alunos</td>
            </tr>
            <tr>
                <td align="right">Nome do Aluno:</td>
                <td><input type="text" name="nome"></td>
                <td align="right">Data de Nascimento:</td>
                <td><input type="date" name="data_ncto"></td>
                <td align="right">Código do Município:</td>
                <td><input type="text" name="fk_municipio_codigo"></td>
                <td align="right">Nome da UF:</td>
                <td><input type="text" name="fk_uf_codigo"></td>
                <td><input type="submit" name="botao" value="Gerar"></td>
            </tr>
        </table>
    </form>

    <?php
    if (@$_POST['botao'] == "Gerar") {
        $nome = $_POST['nome'] ?? '';
        $data_ncto = $_POST['data_ncto'] ?? '';
        $fk_municipio_codigo = $_POST['fk_municipio_codigo'] ?? '';
        $fk_uf_codigo = $_POST['fk_uf_codigo'] ?? '';

        $query = "SELECT aluno.nome AS nome_aluno, cursa.turma
                  FROM aluno
                  INNER JOIN cursa ON aluno.codigo = cursa.fk_aluno_codigo";

        if (!empty($nome)) {
            $query .= " WHERE aluno.nome LIKE '%$nome%'";
        }

        $result = mysqli_query($mysqli, $query);

        echo "<table border='1' align='center'>";
        echo "<tr>";
        echo "<th>Nome do Aluno</th>";
        echo "<th>Turma</th>";
        echo "</tr>";

        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row['nome_aluno'] . "</td>";
            echo "<td>" . $row['turma'] . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    }
    ?>
</body>
</html>
