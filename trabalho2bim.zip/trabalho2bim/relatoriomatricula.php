<html>
<head>
<title>Relatório de Matrículas</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="relatoriomatricula.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan=5 align="center">Relatório do Aluno</td>
  </tr>
  <tr>
    <td width="9%" align="right">Nome Aluno:</td>
    <td width="30%"><input type="text" name="nome"  /></td>
    <td width="12%" align="right">Nome Municipio:</td>
    <td width="26%"><input type="text" name="municipio" size="3" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">
    <th width="25%">Nome do Aluno</th>
    <th width="10%">Idade</th>
    <th width="10%">Municipio</th>
    <th width="10%">UF</th>
    <th width="10%">Disciplina</th>
    <th width="10%">Valor Mensalidade</th>
  </tr>

<?php

    $nome = $_POST['nome'];
    $municipio = $_POST['municipio'];
    
    $query = "SELECT aluno.NOME as nome, DATA_NCTO, municipio.NOME as nomeM,uf.NOME as nomeU, disciplina.NOME nomeD, MENSALIDADE, TIMESTAMPDIFF(YEAR, DATA_NCTO, NOW()) AS idade 
              FROM aluno 
        inner join cursa on aluno.CODIGO=cursa.fk_ALUNO_CODIGO
        inner join disciplina on disciplina.CODIGO=cursa.fk_DISCIPLINA_CODIGO 
        inner join municipio on municipio.CODIGO = aluno.fk_MUNICIPIO_CODIGO
        inner join uf on uf.CODIGO = municipio.fk_UF_CODIGO
        WHERE aluno.CODIGO > 0 ";
    $query .= ($nome ? " AND ALUNO.NOME LIKE '%$nome%' " : "");
    $query .= ($municipio ? " AND MUNICIPIO.NOME LIKE '%$municipio%' " : "");
    $query .= " ORDER by aluno.CODIGO";
    $result = mysqli_query($mysqli, $query);

    while ($coluna=mysqli_fetch_array($result)) 
    {
      ?>
    <tr>
      <th width="25%"><?php echo $coluna['nome']; ?></th>
      <th width="20%"><?php echo $coluna['idade'] ?></th>
      <th width="20%"><?php echo $coluna['nomeM']; ?></th>
      <th width="25%"><?php echo $coluna['nomeU']; ?></th>
      <th width="25%"><?php echo $coluna['nomeD']; ?></th>
      <th width="25%"><?php echo $coluna['MENSALIDADE']; ?></th>
    </tr>
    <?php
    
    } // fim while
?>
</table>
<?php   
}
?>
<a href="index.html" >Home </a>

</body>
