<!DOCTYPE html>
<html>
<head>
    <title>Relatório de Mensalidade Agrupada por Região, Ano e Disciplina</title>
    <?php include('config.php'); ?>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
    <form action="relatoriomateria.php" method="post" name="form1">
        <table width="95%" border="1" align="center">
            <tr>
                <td colspan="5" align="center">Relatório de Mensalidade Agrupada</td>
            </tr>
            <tr>
                <td align="right">Nome do Aluno:</td>
                <td><input type="text" name="nome"></td>
                <td align="right">Data de Nascimento:</td>
                <td><input type="date" name="data_ncto"></td>
                <td align="right">Código do Município:</td>
                <td><input type="text" name="fk_municipio_codigo"></td>
                <td align="right">Nome da UF:</td>
                <td><input type="text" name="fk_uf_codigo"></td>
                <td><input type="submit" name="botao" value="Gerar"></td>
            </tr>
        </table>
    </form>

    <?php
    if (@$_POST['botao'] == "Gerar") {
        $nome = $_POST['nome'] ?? '';
        $data_ncto = $_POST['data_ncto'] ?? '';
        $fk_municipio_codigo = $_POST['fk_municipio_codigo'] ?? '';
        $fk_uf_codigo = $_POST['fk_uf_codigo'] ?? '';

        $query = "SELECT uf.nome AS regiao, 
                         YEAR(aluno.data_ncto) AS ano, 
                         disciplina.nome AS disciplina, 
                         SUM(disciplina.mensalidade) AS total_mensalidade 
                  FROM aluno 
                  INNER JOIN cursa ON aluno.codigo = cursa.fk_aluno_codigo
                  INNER JOIN disciplina ON disciplina.codigo = cursa.fk_disciplina_codigo 
                  INNER JOIN municipio ON municipio.codigo = aluno.fk_municipio_codigo
                  INNER JOIN uf ON uf.codigo = municipio.fk_uf_codigo";

        if (!empty($nome)) {
            $query .= " WHERE aluno.nome LIKE '%$nome%'";
        }

        $query .= " GROUP BY uf.nome, YEAR(aluno.data_ncto), disciplina.nome";
        $query .= " ORDER BY uf.nome, YEAR(aluno.data_ncto), disciplina.nome";

        $result = mysqli_query($mysqli, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<table border='1' align='center'>";
            echo "<tr>";
            echo "<th>Região</th>";
            echo "<th>Ano</th>";
            echo "<th>Disciplina</th>";
            echo "<th>Total Mensalidade</th>";
            echo "</tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['regiao'] . "</td>";
                echo "<td>" . $row['ano'] . "</td>";
                echo "<td>" . $row['disciplina'] . "</td>";
                echo "<td>" . $row['total_mensalidade'] . "</td>";
                echo "</tr>";
            }

            echo "</table>";
        } else {
            echo "<p>Nenhum resultado encontrado para os critérios de busca.</p>";
        }
    }
    ?>
</body>
</html>
