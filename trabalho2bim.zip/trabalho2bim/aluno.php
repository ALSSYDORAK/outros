<html>

<head>
<title>Cadastro de Alunos</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="aluno.php" method="post" name="aluno">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de Alunos</td>
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>cpf:</td>
    <td><input type="number" name="cpf" ></td>
  </tr>
  <tr>
    <td>data de nascimento:</td>
    <td><input type="date" name="data_ncto" ></td>
  </tr>
  <tr>
    <td>Municipio</td>
    <td><input type="int" name="fk_municipio_codigo" ></td>
  </tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>
<?php
if (@$_POST['botao'] == "Gravar") 
	{
    
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $data_ncto = $_POST['data_ncto'];
    $municipio = $_POST['fk_municipio_codigo'];
  
		
		$insere = "INSERT into aluno(nome, cpf, data_ncto, fk_municipio_codigo) VALUES ('$nome', '$cpf', '$data_ncto', '$municipio')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}
?>
<a href="index.html" >Home </a>
</body>
</html>
